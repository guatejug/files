/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.guatejug.springtutoriala.beans;

import java.util.Properties;

/**
 *
 * @author shakamca
 */
public class PropertiesBean {
    private int id;
    private Properties properties;

    public PropertiesBean() {
        this.properties = new Properties();
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the properties
     */
    public Properties getProperties() {
        return properties;
    }

    /**
     * @param properties the properties to set
     */
    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PropertiesBean = {id = ").append(this.id).
                append(", properties = ").append(this.properties).
                append("}");
        return builder.toString();
    }
    
    
    
    
}
