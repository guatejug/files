package gt.edu.guatejug.springtutoriala;

import gt.edu.guatejug.springtutoriala.beans.BasicBean;
import gt.edu.guatejug.springtutoriala.beans.CompositeBean;
import gt.edu.guatejug.springtutoriala.beans.ListBean;
import gt.edu.guatejug.springtutoriala.beans.MapBean;
import gt.edu.guatejug.springtutoriala.beans.PropertiesBean;
import gt.edu.guatejug.springtutoriala.beans.SetBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * 
 *
 */
public class App {

    public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext("resources/applicationContext.xml");


        BasicBean basicBean = (BasicBean) context.getBean("basicBeanConf1");
        System.out.println(basicBean.toString());

        basicBean = (BasicBean) context.getBean("basicBeanConf2");
        System.out.println(basicBean.toString());

        basicBean = (BasicBean) context.getBean("basicBeanConf3");
        System.out.println(basicBean.toString());

        basicBean = (BasicBean) context.getBean("basicBeanConf4");
        System.out.println(basicBean.toString());
        
        ListBean listBean = (ListBean) context.getBean("listBean");
        System.out.println(listBean.toString());
        
        MapBean mapBean = (MapBean) context.getBean("mapBean");
        System.out.println(mapBean.toString());
        
        SetBean setBean = (SetBean) context.getBean("setBean");
        System.out.println(setBean.toString());
        
        PropertiesBean propertiesBean = (PropertiesBean) context.getBean("propertiesBean");
        System.out.println(propertiesBean.toString());
        
        CompositeBean compositeBean = (CompositeBean) context.getBean("compositeBean");
        System.out.println(compositeBean.toString());

    }
}
