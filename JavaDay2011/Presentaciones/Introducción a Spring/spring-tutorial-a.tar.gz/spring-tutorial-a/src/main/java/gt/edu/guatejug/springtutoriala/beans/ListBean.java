/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.guatejug.springtutoriala.beans;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author shakamca
 */
public class ListBean {
    private int id;
    private List list;

    public ListBean() {
        this.list = new ArrayList();
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the list
     */
    public List getList() {
        return list;
    }

    /**
     * @param list the list to set
     */
    public void setList(List list) {
        this.list = list;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ListBean = {id = ").append(this.id).
                append(", list = ").append(this.list).
                append("}");
        return builder.toString();
    }
    
    
    
    
    
}
