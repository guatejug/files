/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.guatejug.springtutoriala.beans;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author shakamca
 */
public class SetBean {
    private int id;
    private Set set;

    public SetBean() {
        this.set = new HashSet();
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the set
     */
    public Set getSet() {
        return set;
    }

    /**
     * @param set the set to set
     */
    public void setSet(Set set) {
        this.set = set;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SetBean = {id = ").append(this.id).
                append(", set = ").append(this.set).
                append("}");
        return builder.toString();
    }
    
    
    
}
