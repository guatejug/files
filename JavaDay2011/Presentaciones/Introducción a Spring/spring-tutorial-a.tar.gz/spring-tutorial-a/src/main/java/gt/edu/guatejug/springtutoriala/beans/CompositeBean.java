/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.guatejug.springtutoriala.beans;

/**
 *
 * @author shakamca
 */
public class CompositeBean {
    private int id;
    private ListBean listBean;
    private SetBean setBean;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the listBean
     */
    public ListBean getListBean() {
        return listBean;
    }

    /**
     * @param listBean the listBean to set
     */
    public void setListBean(ListBean listBean) {
        this.listBean = listBean;
    }

    /**
     * @return the setBean
     */
    public SetBean getSetBean() {
        return setBean;
    }

    /**
     * @param setBean the setBean to set
     */
    public void setSetBean(SetBean setBean) {
        this.setBean = setBean;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CompositeBean = {id = ").append(this.id).
                append(", listBean = ").append(this.listBean.toString()).
                append(", setBean = ").append(this.setBean.toString()).
                append("}");
        return builder.toString();
    }
 
    
    
}
