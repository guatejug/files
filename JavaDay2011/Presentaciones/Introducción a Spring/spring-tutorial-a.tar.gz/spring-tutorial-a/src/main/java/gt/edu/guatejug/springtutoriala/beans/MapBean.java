/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.edu.guatejug.springtutoriala.beans;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author shakamca
 */
public class MapBean {
    private int id;
    private Map map;

    public MapBean() {
        this.map = new HashMap();
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the map
     */
    public Map getMap() {
        return map;
    }

    /**
     * @param map the map to set
     */
    public void setMap(Map map) {
        this.map = map;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("MapBean = {id = ").append(this.id).
                append(", map = ").append(this.map).
                append("}");
        return builder.toString();
    }
    
    
    
    
}
