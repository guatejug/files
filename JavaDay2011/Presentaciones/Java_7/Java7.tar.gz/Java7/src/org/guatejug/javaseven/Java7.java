package org.guatejug.javaseven;

/**
 * Case de prueba para las caracteristicas de java 7
 * @author tuxtor
 */
public class Java7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StringTester sTester = new StringTester();
//        sTester.doTest("holaamigos");
//        sTester.doTest("guatejug");
        sTester.doOldTest("holaamigos");
        sTester.doOldTest("guatejug");
        
        NumericTester nTester = new NumericTester();
//        nTester.doTest();
        nTester.doOldTest();
        
        MultiCatchTester cTester = new MultiCatchTester();
//        cTester.doTest(0);
//        cTester.doTest(1);
        cTester.doOldTest(0);
        cTester.doOldTest(1);
        
        ResourceTester rTester = new ResourceTester();
//        rTester.doTest();
        rTester.doOldTest();
    }
}
