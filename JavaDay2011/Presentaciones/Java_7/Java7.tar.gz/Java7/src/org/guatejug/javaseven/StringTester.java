package org.guatejug.javaseven;

/**
 *
 * @author tuxtor
 */
public class StringTester {
    public void doTest(String fooString){
//        switch (fooString) {
//            case "hola":
//                System.out.println("hola amigos");
//                break;
//            case "guatejug":
//                System.out.println("guatejug");
//                break;
//            default:
//                System.out.println("d(ñ_ñ)");
//                break;
//        }

    }
    
    public void doOldTest(String fooString){
        if(fooString.equalsIgnoreCase("hola")){
            System.out.println("hola amigos");
        }else if(fooString.equalsIgnoreCase("guatejug")){
            System.out.println("guatejug");
        }else{
            System.out.println("d(ñ_ñ)");
        }
    }
}
