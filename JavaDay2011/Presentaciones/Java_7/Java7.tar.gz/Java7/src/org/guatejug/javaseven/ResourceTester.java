package org.guatejug.javaseven;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author tuxtor
 */
public class ResourceTester {
    public void doTest(){
//        try (final BufferedReader br = new BufferedReader(new FileReader("./prueba.txt"))) {
//           String line;
//           while ((line = br.readLine()) != null) {
//               System.out.println(line);
//           }
//        } catch (final IOException e) {
//            System.out.println(e.toString());
//        }
    }
    
    public void doOldTest(){
        BufferedReader br;
        try{
           br = new BufferedReader(new FileReader("./prueba.txt"));
           String line;
           while ((line = br.readLine()) != null) {
               System.out.println(line);//Puede fallar aca
           }
           br.close(); //Y ya no llegar aca
           System.out.println(":(");
        } catch (final IOException e) {
            System.out.println(e.toString());
        } finally{
            
        }
    }
}
