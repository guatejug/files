package org.guatejug.javaseven;

/**
 *
 * @author tuxtor
 */
class ExcepcionA extends Exception {
};

class ExcepcionB extends Exception {
};

public class MultiCatchTester {

    public void doTest(int a) {
//    try {
//        if (a == 0) {
//            throw new ExcepcionA();
//        }
//        if (a > 0) {
//            throw new ExcepcionB();
//        }
//    } catch (ExcepcionA|ExcepcionB ex) {
//        System.out.println(ex.getClass() + 
//             " fue lanzada");
//    }
    }

    public void doOldTest(int a) {
        try {
            if (a == 0) {
                throw new ExcepcionA();
            }
            if (a > 0) {
                throw new ExcepcionB();
            }
        } catch (ExcepcionA ex) {
            System.out.println(ex.getClass()
                    + " fue lanzada");
        } catch (ExcepcionB ex) {
            System.out.println(ex.getClass()
                    + " fue lanzada");
        }
    }
}
