
package org.guatejug.javaseven;

/**
 *
 * @author tuxtor
 */
public class NumericTester {
    public void doTest(){
//        //Ejemplo binary literals
//        int fooBinary=0b10001;
//        System.out.println(fooBinary);
//        
//        //Underscores
//        long fooUnderscore=99_999_999
//        System.out.println(1+fooUnderscore);
    }
    
    public void doOldTest(){
        int fooBinary=16;
        System.out.println(fooBinary);
        
        //Underscores
        long fooUnderscore=99999999;
        System.out.println(1+fooUnderscore);
    }
}
