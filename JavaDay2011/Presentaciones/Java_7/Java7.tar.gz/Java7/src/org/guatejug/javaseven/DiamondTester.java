
package org.guatejug.javaseven;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tuxtor
 */
public class DiamondTester {
    public void doTest(String a, String b){
//        List<String> listTest=new ArrayList<>();
//        listTest.add(a);
//        listTest.add(b);
    }
    
    public void doOldTest(String a, String b){
        List<String> listTest=new ArrayList<String>();
        listTest.add(a);
        listTest.add(b);
    }
}
