/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gt.javaday.ssl.sparkhttps;

import spark.Service;
import static spark.Service.ignite;
import static spark.Spark.get;
import static spark.Spark.secure;

/**
 *
 * @author marcos
 */
public class SSLSpark {

    public static void main(String[] args) {

        igniteFirstSpark();
        igniteSecureSpark();
    }

    static void igniteFirstSpark() {
        Service http = ignite()
                .port(8081)
                .threadPool(20);

        http.get("/configuredHello", (q, a) -> "<H1>Hello from port 8081!</H1>");
    }

    static void igniteSecureSpark() {
        Service http = ignite()
                .port(9443)
                .secure("/tools/sslcertificates/tomcat/keystore.jks", "mypass", null, null)
                .threadPool(20);

        http.get("/secureHello", (q, a) -> "<H1>Hello from port 9443!</H1>");
    }

}
